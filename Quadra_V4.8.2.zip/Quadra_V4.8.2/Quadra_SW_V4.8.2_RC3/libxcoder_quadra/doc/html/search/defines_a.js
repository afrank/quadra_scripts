var searchData=
[
  ['lba_5fbit_5foffset_8734',['LBA_BIT_OFFSET',['../ni__nvme_8h.html#a10c2ff4cc4be32ff4d6e3fba96879bf3',1,'ni_nvme.h']]],
  ['lib_5fapi_8735',['LIB_API',['../ni__libxcoder__dynamic__loading_8h.html#a77278c8cc96e39fb27b5d0a347c8fb3d',1,'LIB_API():&#160;ni_libxcoder_dynamic_loading.h'],['../ni__quadra__filter__api_8h.html#a77278c8cc96e39fb27b5d0a347c8fb3d',1,'LIB_API():&#160;ni_quadra_filter_api.h']]],
  ['libxcoder_5fapi_5fversion_8736',['LIBXCODER_API_VERSION',['../ni__defs_8h.html#a316679bd1e50fa8b68efd7a36f5ab359',1,'ni_defs.h']]],
  ['libxcoder_5fapi_5fversion_5fmajor_8737',['LIBXCODER_API_VERSION_MAJOR',['../ni__defs_8h.html#a0e643bfbbb36f6b6276cfa45633bf336',1,'ni_defs.h']]],
  ['libxcoder_5fapi_5fversion_5fminor_8738',['LIBXCODER_API_VERSION_MINOR',['../ni__defs_8h.html#a2bf181943f05c4327155ccc4e3aaaf43',1,'ni_defs.h']]],
  ['load_5foffset_5fin_5f4k_8739',['LOAD_OFFSET_IN_4K',['../ni__nvme_8h.html#afdb66d2df19cab8be412b7cd5d155dbe',1,'ni_nvme.h']]],
  ['lock_5fdir_8740',['LOCK_DIR',['../ni__rsrc__priv_8h.html#aa7f4787da1c1b2255c5617df33b8225c',1,'ni_rsrc_priv.h']]],
  ['lock_5fwait_8741',['LOCK_WAIT',['../ni__rsrc__priv_8h.html#a92ad796dd0adc2da08468a220376fe76',1,'ni_rsrc_priv.h']]],
  ['log_5ftag_8742',['LOG_TAG',['../_i_shared_buffer_8cpp.html#a7ce0df38eb467e59f209470c8f5ac4e6',1,'LOG_TAG():&#160;ISharedBuffer.cpp'],['../ni__rsrc__api__android_8h.html#a7ce0df38eb467e59f209470c8f5ac4e6',1,'LOG_TAG():&#160;ni_rsrc_api_android.h']]],
  ['lreturn_8743',['LRETURN',['../ni__defs_8h.html#ac52843a63d161bc12b9d52990114f51b',1,'ni_defs.h']]]
];
