var searchData=
[
  ['zerocopy_5fmode_4732',['zerocopy_mode',['../struct__ni__xcoder__params.html#a441646fad152c74130b44e710f662621',1,'_ni_xcoder_params']]],
  ['zeropoint_4733',['zeroPoint',['../struct__ni__network__layer__params__t.html#a26d3273f06bea34523b4a4a27f0bec54',1,'_ni_network_layer_params_t::zeroPoint()'],['../struct__ni__quadra__network__layer__params__t.html#a26d3273f06bea34523b4a4a27f0bec54',1,'_ni_quadra_network_layer_params_t::zeroPoint()']]]
];
