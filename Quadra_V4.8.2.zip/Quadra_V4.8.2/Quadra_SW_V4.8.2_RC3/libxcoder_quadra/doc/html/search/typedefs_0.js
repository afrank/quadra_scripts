var searchData=
[
  ['avnidevicecontext_7444',['AVNIDeviceContext',['../ni__quadra__filter__api_8h.html#a82888ab1f1dd2b8d8b6fee57549ad657',1,'ni_quadra_filter_api.h']]]
];
