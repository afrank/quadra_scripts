var structtensor__rsrc =
[
    [ "next_idx", "structtensor__rsrc.html#ac9181c82d4010291b078e4a5be4bbc51", null ],
    [ "private", "structtensor__rsrc.html#ad8cc6e120962b4548e2f7d116c4ed560", null ],
    [ "total_num", "structtensor__rsrc.html#a005386dfbba91518eacb7f70ef78c0d7", null ]
];