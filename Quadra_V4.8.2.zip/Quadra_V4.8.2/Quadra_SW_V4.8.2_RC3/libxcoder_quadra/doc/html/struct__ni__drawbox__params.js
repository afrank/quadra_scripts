var struct__ni__drawbox__params =
[
    [ "box_h", "struct__ni__drawbox__params.html#a6ecd66ad2c2bbdc06e32338c3395aa90", null ],
    [ "box_w", "struct__ni__drawbox__params.html#a604b891b6adb8240cd77d559888ff817", null ],
    [ "box_x", "struct__ni__drawbox__params.html#aab07a2a9856549a470a9e77c1a151400", null ],
    [ "box_y", "struct__ni__drawbox__params.html#a3fb8598fe9cb40e570188c77e1c517a5", null ]
];