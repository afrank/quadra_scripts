var struct__ni__quadra__hw__device__info =
[
    [ "available_card_num", "struct__ni__quadra__hw__device__info.html#a23c38245d93dde09cc1eb317517cb5d0", null ],
    [ "card_current_card", "struct__ni__quadra__hw__device__info.html#a54809ef98dcf3890a06eb68c730013b9", null ],
    [ "card_info", "struct__ni__quadra__hw__device__info.html#a60471c39e9e3cd0c984b492ce56c9c8f", null ],
    [ "consider_mem", "struct__ni__quadra__hw__device__info.html#acaf875b036590cab3a4dd8282a262a37", null ],
    [ "device_type", "struct__ni__quadra__hw__device__info.html#ac2e54dff4eb7d23e38512abc5bc7711b", null ],
    [ "device_type_num", "struct__ni__quadra__hw__device__info.html#ac65e64ff1839af724fb5c313cdc28e55", null ],
    [ "err_code", "struct__ni__quadra__hw__device__info.html#a18c05079c393f6c94543830ac5360604", null ]
];