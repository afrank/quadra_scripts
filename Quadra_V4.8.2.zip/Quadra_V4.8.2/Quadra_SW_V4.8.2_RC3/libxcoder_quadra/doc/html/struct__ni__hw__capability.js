var struct__ni__hw__capability =
[
    [ "codec_format", "struct__ni__hw__capability.html#a4b58a392a239233c112224c5c6b67b69", null ],
    [ "codec_type", "struct__ni__hw__capability.html#a5b16cde76ddd2d653b1c6968e015038d", null ],
    [ "hw_id", "struct__ni__hw__capability.html#a93124d2e13be33bebf0974c52bcf4a95", null ],
    [ "max_4k_fps", "struct__ni__hw__capability.html#ac02ddbe68006f9cc8329181bb3ddd17b", null ],
    [ "max_number_of_contexts", "struct__ni__hw__capability.html#a680787066b818b6a92b9fa6c34c81911", null ],
    [ "max_video_height", "struct__ni__hw__capability.html#a4fef4b2fa1a8ae8446314ad0af4ce698", null ],
    [ "max_video_width", "struct__ni__hw__capability.html#ab81ecded1f7c46e120c8f2afa7b2c5cc", null ],
    [ "min_video_height", "struct__ni__hw__capability.html#a43f975508191b1d0d9744ed1e732c027", null ],
    [ "min_video_width", "struct__ni__hw__capability.html#a9538e1d5ae4f9ff8d36300cbb4c00b17", null ],
    [ "reserved", "struct__ni__hw__capability.html#acb7bc06bed6f6408d719334fc41698c7", null ],
    [ "video_level", "struct__ni__hw__capability.html#a4b623f3cc710f9e3edb7da7aee734242", null ],
    [ "video_profile", "struct__ni__hw__capability.html#a6ac0df93e34a92f42f95c483556d0822", null ]
];