var struct__ni__quadra__split__context__t =
[
    [ "enabled", "struct__ni__quadra__split__context__t.html#a03e6cca0c879c0443efb431c30c14f76", null ],
    [ "f", "struct__ni__quadra__split__context__t.html#ae1c6962067b512e7331e2ff0b3613fb9", null ],
    [ "f8b", "struct__ni__quadra__split__context__t.html#a2d3b57036d242c5f5303c2bb20f65494", null ],
    [ "h", "struct__ni__quadra__split__context__t.html#adb2dfef64286e1bf59babab325e3d380", null ],
    [ "w", "struct__ni__quadra__split__context__t.html#a098361ccc77b0cd354e25d766f5b9283", null ]
];