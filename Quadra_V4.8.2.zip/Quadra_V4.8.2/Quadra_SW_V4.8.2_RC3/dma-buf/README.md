## dma-buf README

### Requirements

This Linux kernel driver requires linux kernel to support dma-buf.

Netint driver has release and engineering mode. Default is release mode.
Engineering mode is for self test purpose only. This mode enables
extra kernel threads to do YUV copy using CPUs.

### Build
```
To build with release mode, invoke:
$ make

To build with engineering mode, invoke:
$ make netint_build=eng

```

### Install
```
$ sudo insmod netint.ko
