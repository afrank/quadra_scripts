#!/bin/bash
ARCH=$1
if [ $ARCH = '64' ]
then
        WORK_DIR='android_work'
        LUNCH_CMD='aosp_x86_64-eng'
else
        WORK_DIR='android_work32'
        LUNCH_CMD='aosp_x86-eng'
fi
cd ~/$WORK_DIR && echo OK || echo Error
adb </dev/null shell ni_rsrc_list -a && echo OK || echo Error
adb logcat -d | grep libxcoder && echo OK || echo Error
