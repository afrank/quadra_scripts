# define LOG_TAG "android.hardware.nidec@1.0-service"

# include <android/hardware/nidec/1.0/INidec.h>
#include <binder/IPCThreadState.h>
# include <hidl/LegacySupport.h>

using android::hardware::nidec::V1_0::INidec;
using android::hardware::defaultPassthroughServiceImplementation;

int main() {
    android::ProcessState::initWithDriver("/dev/vndbinder");
    printf("=== nidec ===start service\n");
    return defaultPassthroughServiceImplementation<INidec>();
}
