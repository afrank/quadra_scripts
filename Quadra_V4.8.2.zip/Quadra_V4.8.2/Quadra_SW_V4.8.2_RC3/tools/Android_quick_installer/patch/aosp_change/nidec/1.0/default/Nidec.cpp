#include "Nidec.h"

namespace android {
namespace hardware {
namespace nidec {
namespace V1_0 {
namespace implementation {

using namespace std;

// Methods from ::android::hardware::nidec::V1_0::INidec follow.
Return<void> Nidec::SetAppFlag(const hidl_string& name, const hidl_handle& fd) {
	printf("setappflag: name %s, fd %d\n", name.c_str(), fd->data[0]);
	shmFd[name] = fd;
    return Void();
}

Return<void> Nidec::GetAppFlag(const hidl_string& name, GetAppFlag_cb _hidl_cb) {
	hidl_handle fd;
	int32_t ret = 0;
	printf("getappflag: name %s\n", name.c_str());
    //printf("getappflag: name %s, fd %d\n", name.c_str(), fd->data[0]);
	/*char buf[100];
	::memset(buf, 0x00, 100);
    ::snprintf(buf, 100, "Hello World, %s", name.c_str());*/
	map<hidl_string, hidl_handle>::iterator iter;
    iter = shmFd.find(name.c_str());
    if (iter != shmFd.end())
    {
      fd = iter->second;
	  printf("getappflag: name %s, fd %d\n", name.c_str(), fd->data[0]);
	  //int fd2 = dup(fd);
	  //printf("getappflag: name %s, dup fd2 %d\n", name.c_str(), fd2);
	  ret = 1;
    }
	_hidl_cb(ret, fd);
	//printf("getappflag: fd %p\n", fd);
    return Void();
}


// Methods from ::android::hidl::base::V1_0::IBase follow.

INidec* HIDL_FETCH_INidec(const char* /* name */) {
    return new Nidec();
}
//
}  // namespace implementation
}  // namespace V1_0
}  // namespace nidec
}  // namespace hardware
}  // namespace android
