*Note: just support VS2019(Visual Studio 2019) build ffmpeg v4.3.1 release dll and lib of x64;
       win32 or debug is not supported now;
       libxcoder_logan can support all of them;
	   the following takes the X64 release compiling as an example;
       Reference:https://github.com/ShiftMediaProject/FFmpeg;

1. config the vs2019 environment
  1) install vs2019 (community or professional)
  2) install assembly tools of yasm and nasm in vs2019;
    the latest tools are in file "..\tools\MSVS2019\NI_MSVS2019-n4.3.1\3rd_tools";
    refer to the Readme.txt to install them.
	  
2. build with vs2019
  1) copy the projects file "NI_MSVS2019-n4.3.1" in "..\tools\MSVS2019" to "..\FFmpeg-n4.3.1";
  2) build libxcoder_logan:
      a. go to "..\libxcoder_logan\MSVS2019\libxcoder_logan", open VS solution file libxcoder_logan.sln, select the configuration and platform, then build them;
      b. after completed, the exe, lib or dll are located in "..\libxcoder_logan\build";
  3) build ffmpeg-n4.3.1:
      a. copy ni_defs.h,ni_util.h,ni_device_api.h,ni_rsrc_api.h in "..\libxcoder_logan\source" to "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\3rd_libs\libxcoder_logan\include";
      b. To build lib, copy libxcoder_logan.lib and libxcoder_logan.pdb in "..\libxcoder_logan\build" to "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\3rd_libs\libxcoder_logan\lib\x64\Release";
         To build dll, copy libxcoder_logan.dll and libxcoder_logan.lib in "..\libxcoder_logan\build" to "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\3rd_libs\libxcoder_logan\lib\x64\ReleaseDLL";
      c. go to "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1", open VS solution file FFmpeg-n4.3.1.sln, select the configuration and platform, then build them;
      d. after completed, the exe, lib or dll are located in "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\build";

3. run the test:
  a. open a windows terminal with administrator privileges. Go to "..\libxcoder_logan\build", do the initialization with running the init_rsrc_logan.exe. init_rsrc_logan.exe must keep running.
  b. open another windows terminal with administrator privileges. Go to "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\build". Run ffmpeg/ffplay/ffprobe exe.
  c. You can also copy all the file in "..\libxcoder_logan\build" and "..\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\build" to another PC, and do the same test.
  *Note: if the test PC doesn't install the vs2019, to run the exe with dll need to install the VC_redist.x64.exe and VC_redist.x86.exe in "..\tools\MSVS2019\NI_MSVS2019-n4.3.1\3rd_tools\VS_redist";

  
	


