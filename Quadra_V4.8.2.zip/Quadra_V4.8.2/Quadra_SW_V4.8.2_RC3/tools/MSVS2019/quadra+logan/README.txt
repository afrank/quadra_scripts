This README is a guideline for the automation tool of the windows VS2019 environment setup only

Environment requirement:
1.Windows 10 x86_64 Operation system
2.Visual Studio 2017/2019 or later installed (assume the default path is C:\)
3.Microsoft Visual Studio Installer Projects extension is installed for Visual Studio 2017/2019
4.NETINT release package for FFMPEG

NOTE: this is a automation process for "APPS537 Codensity T408TM Windows VS2019 SDK build Application Note"

How to setup the environment with this automation tool:
In windows, run batch script "windows_automated_compiling_ffmpeg_nx.x.x.bat" as administrator. As for DLL
mode run "windows_automated_compiling_ffmpeg_nx.x.x_dll.bat".

The relative path is fixed in the ffmpeg directory, below is a tree diagram as a reference for the relative path:

release-------
              -FFMPEG-nx.x.x
              -libxcoder
              -tools-------------------
                                      -MSVS2019-------------
                                                           -3rd_codecs\
                                                           -3rd_libs\
                                                           -3rd_tools\
                                                           -quadra+logan---------
                                                                               -README.txt
                                                                               -NI_MSVS2019-n4.2.1\
                                                                               -NI_MSVS2019-n4.3.1\
                                                                               -NI_MSVS2019-n4.4\
                                                                               -NI_MSVS2019_XCODER\
                                                                               -windows_automated_compiling_ffmpeg.bat
                                                                               -windows_automated_compiling_ffmpeg_dll.bat
                                                                               -windows_automated_compiling_ffmpeg_n4.2.1.bat
                                                                               -windows_automated_compiling_ffmpeg_n4.2.1_dll.bat
                                                                               -windows_automated_compiling_ffmpeg_n4.3.1.bat
                                                                               -windows_automated_compiling_ffmpeg_n4.3.1_dll.bat
                                                                               -windows_automated_compiling_ffmpeg_n4.4.bat
                                                                               -windows_automated_compiling_ffmpeg_n4.4_dll.bat
                                                                               -windows_download_and_patch_ffmpeg.bat

Let's take FFmpeg-n4.3.1 for instance. The final output directory would be C:\FFmpeg-n4.3.1\NI_MSVS2019-n4.3.1\build\
where the following output files would be included:

ffmpeg.exe
ffplay.exe
ffprobe.exe
init_rsrc.exe
init_rsrc_logan.exe
ni_rsrc_list.exe
ni_rsrc_list_logan.exe
ni_rsrc_mon.exe
ni_rsrc_mon_logan.exe
ni_rsrc_namespace.exe
ni_rsrc_update.exe
ni_rsrc_update_logan.exe
SDL2.dll
setup.exe
setup.msi
test_rsrc_api.exe
test_rsrc_api_logan.exe
xcoder.exe
xcoder_logan.exe
zlibwapi.dll

If we would like to build as DLL mode then the output files will be as follows:

ffmpeg.exe
ffplay.exe
ffprobe.exe
init_rsrc.exe
init_rsrc_logan.exe
libavcodec.dll
libavdevice.dll
libavfilter.dll
libavformat.dll
libavresample.dll
libavutil.dll
libpostproc.dll
libswresample.dll
libswscale.dll
libxcoder.dll
libxcoder_logan.dll
ni_rsrc_list.exe
ni_rsrc_list_logan.exe
ni_rsrc_mon.exe
ni_rsrc_mon_logan.exe
ni_rsrc_namespace.exe
ni_rsrc_update.exe
ni_rsrc_update_logan.exe
SDL2.dll
setup.exe
setup.msi
test_rsrc_api.exe
test_rsrc_api_logan.exe
xcoder.exe
xcoder_logan.exe
zlibwapi.dll

Click the setup.msi or setup.exe for installation in which the location path can be costumized. You may use
'Add or Remove programs'system setting to erase earlier installation.
