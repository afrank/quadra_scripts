library folder
copy the libraries from libxcoder/build
