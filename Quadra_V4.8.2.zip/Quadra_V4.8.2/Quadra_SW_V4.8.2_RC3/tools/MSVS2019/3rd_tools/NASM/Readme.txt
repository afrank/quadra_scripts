1. The nasm is download from https://www.nasm.us/pub/nasm/releasebuilds/
2. To install nasm to Visual Studio 2019, you can install by yourself or use install_nasm_script.bat.
   Find the Visual Studio 2019 installation path, for example in "C:" or "D:", etc.
   Take the installation path as C disk as an example here.

   Install by yourself:
   a. copy nasm.props, nasm.targets and nasm.xml to C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Microsoft\VC\v160\BuildCustomizations
   b. copy the corresponding nasm.exe(x86 or x64) in "nasm-2.13.03-winXX" to C:\Program Files (x86)\Microsoft Visual Studio\2019\VC
   
   Install with install_nasm_script.bat:
   a. Run the install script "install_nasm_script.bat" with administrator privileges.
   *Note: the script just support that the Visual Studio 2019 installation path is driver C. Other path you need to change the "VSPATH" variable in the script.
   

