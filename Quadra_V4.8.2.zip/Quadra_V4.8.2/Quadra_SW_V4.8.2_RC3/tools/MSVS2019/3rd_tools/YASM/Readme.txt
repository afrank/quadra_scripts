1. The yasm is download from http://yasm.tortall.net/
2. To install yasm to Visual Studio 2019, you can install by yourself or use install_yasm_script.bat.
   Find the Visual Studio 2019 installation path, for example in "C:" or "D:", etc.
   Take the installation path as C disk as an example here.

   Install by yourself:
   a. copy yasm.props, yasm.targets and yasm.xml to C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Microsoft\VC\v160\BuildCustomizations
   b. copy the corresponding yasm.exe(x86 or x64) in "yasm-1.3.0-winXX" to C:\Program Files (x86)\Microsoft Visual Studio\2019\VC
   
   Install with install_yasm_script.bat:
   a. Run the install script "install_yasm_script.bat" with administrator privileges.
   *Note: the script just support that the Visual Studio 2019 installation path is driver C. Other path you need to change the "VSPATH" variable in the script.
   

