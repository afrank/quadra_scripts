static const AVOutputFormat * const outdev_list[] = {
    &ff_sdl2_muxer,
    NULL };
