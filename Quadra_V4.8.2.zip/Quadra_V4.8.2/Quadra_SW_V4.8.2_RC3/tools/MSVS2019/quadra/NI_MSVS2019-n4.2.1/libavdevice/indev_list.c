static const AVInputFormat * const indev_list[] = {
    &ff_dshow_demuxer,
    &ff_gdigrab_demuxer,
    &ff_lavfi_demuxer,
    &ff_vfwcap_demuxer,
    NULL };
