/*******************************************************************************
 *
 * Copyright (C) 2022 NETINT Technologies
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 ******************************************************************************/

/*!*****************************************************************************
 *  \file   ni_watermark_test.c
 *
 *  \brief  Application for applying watermark using libxcoder API overlay.
 *          Its code provides examples on how to programatically use
 *          libxcoder API.
 ******************************************************************************/

#define _POSIX_C_SOURCE 200809L
#include <getopt.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>

#include "ni_test_utils.h"

#define POOL_SIZE 1
#define MAX_INPUT_FILES 2

static uint8_t tmp_buf[NI_MAX_TX_SZ] = {0};

// simplistic ref counted HW frame
static ni_hwframe_ref_t g_hwframe_pool[NI_MAX_DR_HWDESC_FRAME_INDEX];

int filter_frame(ni_session_context_t *filter_ctx, niFrameSurface1_t *p_uphwframe,
                 ni_session_data_io_t *in_data, ni_session_data_io_t *out_data,
                 ni_scaler_input_params_t *main_params, ni_scaler_input_params_t *upload_params)
{
    int ret = 0;
    frame_copy_props(out_data, in_data);
    // allocate a ni_frame_t structure on the host PC
    ret = ni_frame_buffer_alloc_hwenc(&(out_data->data.frame),
                                      main_params->output_width,
                                      main_params->output_height, 0);
    if (ret != 0) {
        ni_log(NI_LOG_ERROR, "Failed to alloc hwenc\n");
        return -1;
    }

    // Allocate scaler input frame
    ret = ni_scaler_input_frame_alloc(filter_ctx, *upload_params, p_uphwframe);
    if (ret != 0) {
        ni_log(NI_LOG_ERROR, "Failed to alloc input frame\n");
        return -1;
    }

    // Allocate scaler destination frame.
    ret = ni_scaler_dest_frame_alloc(filter_ctx, *main_params, (niFrameSurface1_t *)in_data->data.frame.p_data[3]);
    if (ret != 0) {
        ni_log(NI_LOG_ERROR, "Failed to alloc dest frame\n");
        return -1;
    }

    // Retrieve hardware frame info from 2D engine and put it in the ni_frame_t structure.
    ret = ni_device_session_read_hwdesc(filter_ctx, out_data, NI_DEVICE_TYPE_SCALER);
    if (ret != 0)
    {
        ni_log(NI_LOG_ERROR, "Failed to lauch scaler operation %d\n", main_params->op);
        return -1;
    }

    ni_hwframe_buffer_recycle2((niFrameSurface1_t *)in_data->data.frame.p_data[3]);
    return 0;
}

/*!*****************************************************************************
 *  \brief  decoder session open
 *
 *  \param
 *
 *  \return 0 if successful, < 0 otherwise
 ******************************************************************************/
int decoder_open_session(ni_session_context_t *p_dec_ctx, 
                         ni_xcoder_params_t *p_dec_params,
                         ni_codec_format_t codec_type, int devid,
                         int bit_depth)
{
    int ret = 0;
    p_dec_ctx->session_id = NI_INVALID_SESSION_ID;
    p_dec_ctx->device_handle = NI_INVALID_DEVICE_HANDLE;
    p_dec_ctx->blk_io_handle = NI_INVALID_DEVICE_HANDLE;
    p_dec_ctx->p_session_config = p_dec_params;
    p_dec_ctx->codec_format = codec_type;

    // assign the card GUID in the encoder context and let session open
    // take care of the rest
    p_dec_ctx->hw_id = devid;

    // default: little endian
    p_dec_ctx->src_bit_depth = bit_depth;
    p_dec_ctx->src_endian = NI_FRAME_LITTLE_ENDIAN;
    p_dec_ctx->bit_depth_factor = (bit_depth == 8) ? 1 : 2;

    if (p_dec_params->dec_input_params.hwframes) {
        p_dec_ctx->hw_action = NI_CODEC_HW_ENABLE;
    } else {
        p_dec_ctx->hw_action = NI_CODEC_HW_NONE;
    }

    ret = ni_device_session_open(p_dec_ctx, NI_DEVICE_TYPE_DECODER);

    if (ret != NI_RETCODE_SUCCESS) {
        ni_log(NI_LOG_ERROR, "Error: ni_decoder_session_open() failure!\n");
    }
    return ret;
}

/*!****************************************************************************
 *  \brief  Open an encoder session to Quadra
 *
 *  \param  [out] p_enc_ctx         pointer to an encoder session context
 *          [in]  dst_codec_format  AVC or HEVC
 *          [in]  iXcoderGUID       id to identify the Quadra device
 *          [in]  p_enc_params      sets the encoder parameters
 *          [in]  width             width of frames to encode
 *          [in]  height            height of frames to encode
 *
 *  \return 0 if successful, < 0 otherwise
 ******************************************************************************/
int encoder_open_session(ni_session_context_t *p_enc_ctx, int dst_codec_format,
                         int iXcoderGUID, ni_xcoder_params_t *p_enc_params,
                         int width, int height, ni_frame_t *p_frame)
{
    int ret = 0;

    // Enable hardware frame encoding
    p_enc_ctx->hw_action = NI_CODEC_HW_ENABLE;
    p_enc_params->hwframes = 1;

    // Provide the first frame to the Quadra encoder
    p_enc_params->p_first_frame = p_frame;

    // Specify codec, AVC vs HEVC
    p_enc_ctx->codec_format = dst_codec_format;

    p_enc_ctx->p_session_config = p_enc_params;
    p_enc_ctx->session_id = NI_INVALID_SESSION_ID;

    // Assign the card GUID in the encoder context to open a session
    // to that specific Quadra device
    p_enc_ctx->device_handle = NI_INVALID_DEVICE_HANDLE;
    p_enc_ctx->blk_io_handle = NI_INVALID_DEVICE_HANDLE;
    p_enc_ctx->hw_id = iXcoderGUID;

    ni_encoder_set_input_frame_format(p_enc_ctx, p_enc_params, width, height, 8,
                                      NI_FRAME_LITTLE_ENDIAN, 1);

    ret = ni_device_session_open(p_enc_ctx, NI_DEVICE_TYPE_ENCODER);
    if (ret != NI_RETCODE_SUCCESS) {
        ni_log(NI_LOG_ERROR, "Error: encoder open session failure\n");
    }

    return ret;
}

/*!*****************************************************************************
*  \brief  open scaler session
*
*  \param
*
*  \return 0 if successful, < 0 otherwise
******************************************************************************/
static int scaler_open_session(ni_session_context_t *p_scaler_ctx,
                               int iXcoderGUID, ni_scaler_opcode_t op)
{
    int ret = 0;

    p_scaler_ctx->session_id = NI_INVALID_SESSION_ID;

    p_scaler_ctx->device_handle = NI_INVALID_DEVICE_HANDLE;
    p_scaler_ctx->blk_io_handle = NI_INVALID_DEVICE_HANDLE;
    p_scaler_ctx->hw_id = iXcoderGUID;
    p_scaler_ctx->device_type = NI_DEVICE_TYPE_SCALER;
    p_scaler_ctx->scaler_operation = op;
    p_scaler_ctx->keep_alive_timeout = NI_DEFAULT_KEEP_ALIVE_TIMEOUT;

    ret = ni_device_session_open(p_scaler_ctx, NI_DEVICE_TYPE_SCALER);

    if (ret != NI_RETCODE_SUCCESS) {
        ni_log(NI_LOG_ERROR, "Error: ni_scaler_session_open() failure!\n");
        return -1;
    }

    return 0;
}

/*!****************************************************************************
 *  \brief    Print usage information
 *
 *  \param    none
 *
 *  \return   none
 ******************************************************************************/
void print_usage(void)
{
    printf("Application for applying watermark using libxcoder API overlay\n"
           "Libxcoder release v%s\n"
           "Usage: ni_watermark_test [options]\n"
           "\n"
           "options:\n"
           "  -h | --help        Show help.\n"
           "  -v | --version     Print version info.\n"
           "  -l | --loglevel    Set loglevel of libxcoder API.\n"
           "                     [none, fatal, error, info, debug, trace]\n"
           "                     Default: info\n"
           "  -c | --card        Set card index to use.\n"
           "                     See `ni_rsrc_mon` for cards on system.\n"
           "                     (Default: 0)\n"
           "  -i | --input       Input file path.\n"
           "  -r | --repeat      (Positive integer) to Repeat input X times "
           "for performance \n"
           "                     test. (Default: 1)\n"
           "  -s | --size        Resolution of input file in format "
           "WIDTHxHEIGHT.\n"
           "                     (eg. '1920x1080')\n"
           "  -o | --output      Output file path.\n"
           "  -d | --decoder-params Decode parameters.\n",
           NI_XCODER_REVISION);
}

/*!****************************************************************************
 *  \brief  Parse user command line arguments
 *
 *  \param [in] argc                argument count
 *         [in] argv                argument vector
 *         [out] input_filename     input filename
 *         [out] output_filename    output filename
 *         [out] iXcoderGUID        Quadra device
 *         [out] repeat             input read repeat times
 *         [out] arg_width          resolution width
 *         [out] arg_height         resolution height
 *         [out] dst_codec_format   codec (AVC vs HEVC)
 *
 *  \return nothing                 program exit on error
 ******************************************************************************/
int parse_arguments(int argc, char *argv[], char (*input_filename)[FILE_NAME_LEN],
                    char *output_filename, int *iXcoderGUID, int *repeat, int *arg_width,
                    int *arg_height, int *arg_pic_width, int *arg_pic_height, char *decConfXcoderParams)
{
    char xcoderGUID[32];
    char *n;   // used for parsing width and height from --size
    int opt;
    int opt_index;
    ni_log_level_t log_level;
    static int input_index = 0;
    static int input_resolution_index = 0;

    static const char *opt_string = "hvl:c:i:s:o:r:d:";
    static const struct option long_options[] = {
        {"help", no_argument, NULL, 'h'},
        {"version", no_argument, NULL, 'v'},
        {"loglevel", no_argument, NULL, 'l'},
        {"card", required_argument, NULL, 'c'},
        {"input", required_argument, NULL, 'i'},
        {"size", required_argument, NULL, 's'},
        {"output", required_argument, NULL, 'o'},
        {"repeat", required_argument, NULL, 'r'},
        {"decoder-params", required_argument, NULL, 'd'},
        {NULL, 0, NULL, 0},
    };

    while ((opt = getopt_long(argc, argv, opt_string, long_options,
                              &opt_index)) != -1) {
        switch (opt) {
        case 'h':
            print_usage();
            return 1;
        case 'v':
            printf("Release ver: %s\n"
                   "API ver:     %s\n"
                   "Date:        %s\n"
                   "ID:          %s\n",
                   NI_XCODER_REVISION, LIBXCODER_API_VERSION,
                   NI_SW_RELEASE_TIME, NI_SW_RELEASE_ID);
            return 1;
        case 'l':
            log_level = arg_to_ni_log_level(optarg);
            if (log_level != NI_LOG_INVALID) {
                ni_log_set_level(log_level);
            } else {
                arg_error_exit("-l | --loglevel", optarg);
            }
            break;
        case 'c':
            strcpy(xcoderGUID, optarg);
            *iXcoderGUID = (int)strtol(optarg, &n, 10);
            // No numeric characters found in left side of optarg
            if (n == xcoderGUID)
                arg_error_exit("-c | --card", optarg);
            break;
        case 'i':
            if (input_index == MAX_INPUT_FILES) {
                ni_log(NI_LOG_ERROR, 
                       "Error: number of input files cannot exceed %d\n", MAX_INPUT_FILES);
                return -1;
            }
            strcpy(input_filename[input_index], optarg);
            input_index++;
            break;
        case 's':
            if(input_resolution_index == 0) {
                *arg_width = (int)strtol(optarg, &n, 10);
                *arg_height = atoi(n + 1);
                if ((*n != 'x') || (!*arg_width || !*arg_height))
                    arg_error_exit("-s | --size", optarg);
                input_resolution_index++;
            } else {
                *arg_pic_width = (int)strtol(optarg, &n, 10);
                *arg_pic_height = atoi(n + 1);
                if ((*n != 'x') || (!*arg_pic_width || !*arg_pic_height))
                    arg_error_exit("-s | --size", optarg);
            }
            break;
        case 'o':
            strcpy(output_filename, optarg);
            break;
        case 'r':
            if (!(atoi(optarg) >= 1))
                arg_error_exit("-r | --repeat", optarg);
            *repeat = atoi(optarg);
            break;
        case 'd':
            strcpy(decConfXcoderParams, optarg);
            break;
        default:
            print_usage();
            return -1;
        }
    }

    // Check required args are present
    if (!input_filename[0]) {
        ni_log(NI_LOG_ERROR, "Error: missing argument for -i | --input\n");
        return -1;
    }

    if (!output_filename[0]) {
        ni_log(NI_LOG_ERROR, "Error: missing argument for -o | --output\n");
        return -1;
    }
    return 0;
}

static int encoder_receive(ni_session_context_t *enc_ctx_list,
                           ni_session_data_io_t *pkt,
                           uint32_t *number_of_packets_list,
                           int output_total, FILE **pfs_list,
                           device_state_t *xcoder_state)
{
    int i, recycle_index;
    int recv_fin_flag = NI_TEST_RETCODE_SUCCESS;
    uint32_t prev_num_pkt[1] = {0};

    for (i = 0; i < output_total; i++) {
        pkt->data.packet.end_of_stream = 0;
        prev_num_pkt[i] = number_of_packets_list[i];

        recv_fin_flag = encoder_receive_data(&enc_ctx_list[i], pkt, pfs_list[i],
                                             &number_of_packets_list[i]);

        recycle_index = pkt->data.packet.recycle_index;
        if (prev_num_pkt[i] < number_of_packets_list[i] &&
            enc_ctx_list[i].hw_action && recycle_index > 0 &&
            recycle_index < NI_GET_MAX_HWDESC_FRAME_INDEX(enc_ctx_list[i].ddr_config)) {
            //encoder only returns valid recycle index
            //when there's something to recycle.
            //This range is suitable for all memory bins
            ni_hw_frame_unref(g_hwframe_pool, recycle_index);
        } else {
            ni_log(NI_LOG_DEBUG, "enc %d recv, prev_num_pkt %u "
                   "number_of_packets_list %u recycle_index %u\n", i,
                   prev_num_pkt[i], number_of_packets_list[i], recycle_index);
        }

        xcoder_state[i].enc_eos_received = pkt->data.packet.end_of_stream;

        if (recv_fin_flag < 0) {
            ni_log(NI_LOG_DEBUG, "enc %d error, quit !\n", i);
            break;
        } else if (recv_fin_flag == NI_TEST_RETCODE_EAGAIN) {
            ni_usleep(100);
        }
    }

    return recv_fin_flag;
}

int main(int argc, char *argv[])
{
    static char input_filename[MAX_INPUT_FILES][FILE_NAME_LEN];
    static char output_filename[FILE_NAME_LEN];
    uint32_t number_of_packets_list = 0;
    int input_video_width;
    int input_video_height;
    int iXcoderGUID = 0;
    int repeat = 1;
    int arg_width = 0;
    int arg_height = 0;
    int arg_pic_width;
    int arg_pic_height;
    int input_exhausted = 0;
    int dst_codec_format = NI_CODEC_FORMAT_H265;
    int send_fin_flag = 0;
    int receive_fin_flag = 0;
    int end_of_all_streams = 0;
    int ret;
    int print_time = 0;
    int input_index = 0;
    char decConfXcoderParams[2048] = {0};
    FILE *p_file = NULL;
    ni_xcoder_params_t p_dec_api_param = {0};
    ni_xcoder_params_t p_enc_api_param = {0};
    ni_session_context_t dec_ctx = {0};
    ni_session_context_t enc_ctx = {0};
    ni_session_context_t upl_ctx = {0};
    ni_session_context_t watermark_ctx = {0};
    ni_session_data_io_t out_packet = {0};
    int input_file_fd[MAX_INPUT_FILES] = {-1};
    ni_session_data_io_t in_frame = {0};
    ni_session_data_io_t swin_frame = {0};
    ni_session_data_io_t in_pkt = {0};
    ni_session_data_io_t out_frame = {0};
    ni_session_data_io_t watermark_data = {0};
    ni_session_data_io_t enc_in_frame = {0};
    niFrameSurface1_t *p_hwframe = NULL, *p_uphwframe = NULL;
    ni_scaler_multi_watermark_params_t scaler_watermark_params;
    ni_h264_sps_t SPS = {0};   // input header SPS
    device_state_t xcoder_state = {0};
    ni_file_reader_t *temp_reader = NULL;
    ni_file_reader_t file_reader[MAX_INPUT_FILES] = {0};
    void *yuv_buf = NULL;

    uint32_t number_of_frames = 0;
    struct timeval start_time;
    struct timeval previous_time;
    struct timeval current_time;
    uint32_t time_diff;

    ret = parse_arguments(argc, argv, input_filename, output_filename, &iXcoderGUID, &repeat,
                          &arg_width, &arg_height, &arg_pic_width, &arg_pic_height, decConfXcoderParams);
    if (ret < 0) {
        ni_log(NI_LOG_ERROR, "parse_arguments\n");
        return ret;
    } else if (ret > 0) {
        return 0;
    }

    for(input_index = 0; input_index < MAX_INPUT_FILES; input_index++) {
        // Load input file into memory
        temp_reader = &file_reader[input_index];
        if (load_input_file(input_filename[input_index], &temp_reader->total_file_size) < 0) {
            return -1;
        }
        temp_reader->loop = repeat;
        temp_reader->data_left_size = temp_reader->total_file_size;
#ifdef _WIN32
        input_file_fd[input_index] = open(input_filename[input_index], O_RDONLY | O_BINARY);
#else
        input_file_fd[input_index] = open(input_filename[input_index], O_RDONLY);
#endif

        if (input_file_fd[input_index] < 0) {
            ni_log(NI_LOG_ERROR, "Error: can not open input file %s\n", input_filename[input_index]);
            return -1;
        }
    }

    //load decode file
    ret = read_input_file(&file_reader[0], input_file_fd[0]);
    if (ret) {
        ni_log(NI_LOG_ERROR, "Error: input file %s read error\n", input_filename[0]);
        goto end;
    }

    // Create output file
    if (strcmp(output_filename, "null") != 0) {
        p_file = fopen(output_filename, "wb");
        if (p_file == NULL) {
            ni_log(NI_LOG_ERROR, "Error: cannot open %s\n", output_filename);
            goto end;
        }
    }

    ni_log(NI_LOG_INFO, "SUCCESS: Opened output file: %s\n", output_filename);

    if (ni_decoder_init_default_params(&p_dec_api_param, 30, 1, 200000, arg_width,
                                       arg_height) < 0) {
        ni_log(NI_LOG_ERROR, "Error: decoder p_config set up error\n");
        return -1;
    }

    if (ni_device_session_context_init(&dec_ctx) < 0) {
        ni_log(NI_LOG_ERROR, "Error: init decoder context error\n");
        return -1;
    }

    if (ni_device_session_context_init(&enc_ctx) < 0) {
        ni_log(NI_LOG_ERROR, "Error: init encoder context error\n");
        return -1;
    }

    if (ni_device_session_context_init(&upl_ctx) < 0) {
        ni_log(NI_LOG_ERROR, "Error: init uploader context error\n");
        return -1;
    }

    if (ni_device_session_context_init(&watermark_ctx) < 0) {
        ni_log(NI_LOG_ERROR, "Error: init scaler context error\n");
        return -1;
    }

    ni_log(NI_LOG_INFO, "User video resolution: %dx%d\n", arg_width, arg_height);

    input_video_width = arg_width;
    input_video_height = arg_height;

    ni_gettimeofday(&start_time, NULL);
    ni_gettimeofday(&previous_time, NULL);
    ni_gettimeofday(&current_time, NULL);

    // check and set ni_decoder_params from --xcoder-params
    if (ni_retrieve_decoder_params(decConfXcoderParams, &p_dec_api_param,
                                   &dec_ctx)) {
        ni_log(NI_LOG_ERROR, "Error: encoder p_config parsing error\n");
        return -1;
    }

    // Configure the encoder parameter structure. We'll use some basic
    // defaults: 30 fps, 200000 bps CBR encoding, AVC or HEVC encoding
    if (ni_encoder_init_default_params(&p_enc_api_param, 30, 1, 200000, arg_width,
                                       arg_height, enc_ctx.codec_format) < 0) {
        ni_log(NI_LOG_ERROR, "Error: encoder init default set up error\n");
        return -1;
    }

    // Decode, set default param for dec_ctx
    ni_codec_format_t codec_type = NI_CODEC_FORMAT_H264;
    int bit_depth = 8;
    ret = decoder_open_session(&dec_ctx, &p_dec_api_param, codec_type,
                               iXcoderGUID, bit_depth);
    if (ret != 0) {
        goto end;
    }

    // Open an uploader session to Quadra
    if (uploader_open_session(&upl_ctx, arg_pic_width, arg_pic_height, 
                              NI_PIX_FMT_ABGR, POOL_SIZE, iXcoderGUID)) {
        ni_device_session_close(&dec_ctx, 1, NI_DEVICE_TYPE_DECODER);
        goto end;
    }
    yuv_buf = malloc(MAX_RGBA_FRAME_SIZE);
    if(!yuv_buf)
    {
        ni_log(NI_LOG_ERROR, "Error: allocate yuv buf fail\n");
        goto end;
    }

    ni_scaler_input_params_t upload_params = {0};
    upload_params.input_format = GC620_RGBA8888;
    upload_params.in_rec_width = upload_params.input_width = arg_pic_width;
    upload_params.in_rec_height = upload_params.input_height = arg_pic_height;

    ret = hwup_frame(&upl_ctx, &swin_frame, &in_frame,  
                     input_file_fd[1], 0, &file_reader[1],
                     &input_exhausted, yuv_buf);
    p_uphwframe = (niFrameSurface1_t *)(in_frame.data.frame.p_data[3]);
    ni_frame_buffer_free(&(swin_frame.data.frame));
    // upload an rgba frame to quadra
    if (ret) {
        ni_log(NI_LOG_ERROR, "Error: upload frame error\n");
        ni_device_session_close(&dec_ctx, 1, NI_DEVICE_TYPE_DECODER);
        ni_device_session_close(&upl_ctx, 1, NI_DEVICE_TYPE_UPLOAD);
        goto end;
    }

    ni_scaler_input_params_t watermark_params = {0};
    watermark_params.input_format = GC620_I420;
    watermark_params.in_rec_width = watermark_params.input_width = input_video_width;
    watermark_params.in_rec_height = watermark_params.input_height = input_video_height;
    watermark_params.output_format = GC620_I420;
    watermark_params.out_rec_width = watermark_params.output_width = input_video_width;
    watermark_params.out_rec_height = watermark_params.output_height = input_video_height;
    watermark_params.op = NI_SCALER_OPCODE_WATERMARK;

    watermark_params.out_rec_x = 0;
    watermark_params.out_rec_y = 0;
    watermark_params.rgba_color = 0;

    // params set by user
    watermark_params.in_rec_x = 0;
    watermark_params.in_rec_y = 0;

    if(scaler_open_session(&watermark_ctx, iXcoderGUID, NI_SCALER_OPCODE_WATERMARK)) {
        ni_device_session_close(&dec_ctx, 1, NI_DEVICE_TYPE_DECODER);
        ni_device_session_close(&upl_ctx, 1, NI_DEVICE_TYPE_UPLOAD);
        goto end;
    }

    for(int watermark_idx = 0; watermark_idx < NI_MAX_SUPPORT_WATERMARK_NUM; watermark_idx++)
    {
        scaler_watermark_params.multi_watermark_params[watermark_idx].ui32StartX=200 * watermark_idx;
        scaler_watermark_params.multi_watermark_params[watermark_idx].ui32StartY=100 * watermark_idx;
        scaler_watermark_params.multi_watermark_params[watermark_idx].ui32Width=200;
        scaler_watermark_params.multi_watermark_params[watermark_idx].ui32Height=100;
        scaler_watermark_params.multi_watermark_params[watermark_idx].ui32Valid=1;
    }
    if(ni_scaler_set_watermark_params(&watermark_ctx, &scaler_watermark_params.multi_watermark_params[0])) {
        ni_device_session_close(&dec_ctx, 1, NI_DEVICE_TYPE_DECODER);
        ni_device_session_close(&upl_ctx, 1, NI_DEVICE_TYPE_UPLOAD);
        ni_device_session_close(&watermark_ctx, 1, NI_DEVICE_TYPE_SCALER);
        goto end;
    }

    if (0 != ni_scaler_frame_pool_alloc(&watermark_ctx, watermark_params)) {
        ni_log(NI_LOG_ERROR, "Error: init filter hwframe pool\n");
        ni_device_session_close(&dec_ctx, 1, NI_DEVICE_TYPE_DECODER);
        ni_device_session_close(&upl_ctx, 1, NI_DEVICE_TYPE_UPLOAD);
        ni_device_session_close(&watermark_ctx, 1, NI_DEVICE_TYPE_SCALER);
        goto end;
    }

    while (!end_of_all_streams && (send_fin_flag == 0 || receive_fin_flag == 0)) {
        (void)ni_gettimeofday(&current_time, NULL);
        print_time = current_time.tv_sec - previous_time.tv_sec >= 1;
        if (print_time) {
            previous_time = current_time;
        }
        
decode_send:
        send_fin_flag = decoder_send_data(&dec_ctx, &in_pkt, &xcoder_state,
                                          &file_reader[0], (void *)(&SPS),
                                          input_video_width,
                                          input_video_height, tmp_buf);
        if (send_fin_flag < 0) {
            break;
        }

        // YUV Receiving: not writing to file
        receive_fin_flag = decoder_receive_data(
                               &dec_ctx, &out_frame, &xcoder_state,
                               input_video_width,
                               input_video_height, NULL);

        if (receive_fin_flag == NI_TEST_RETCODE_EAGAIN) {
            ni_log(NI_LOG_DEBUG,
                   "no decoder output, jump to encoder receive!\n");
            if (!dec_ctx.hw_action) {
                ni_decoder_frame_buffer_free(&(out_frame.data.frame));
            } else {
                ni_frame_buffer_free(&(out_frame.data.frame));
            }

            // use first encode config low delay flag for call flow
            if (enc_ctx.session_id != NI_INVALID_SESSION_ID) {
                ni_log(NI_LOG_DEBUG,
                       "no decoder output, jump to encoder receive!\n");
                goto encode_recv;
            } else {
                ni_log(NI_LOG_DEBUG,
                       "no decoder output, encode low_delay, jump to "
                       "decoder send!\n");
                goto decode_send;
            }
        } else if (receive_fin_flag == NI_TEST_RETCODE_SUCCESS) {
            number_of_frames++;
        }

        if (print_time) {
            time_diff = (uint32_t)(current_time.tv_sec - start_time.tv_sec);
            if (time_diff == 0) {
                time_diff = 1;
            }
            ni_log(NI_LOG_INFO, "[DEC] Frames= %u  fps=%f \n",
                   number_of_frames, (float)number_of_frames / (float)time_diff);
        }

        if (receive_fin_flag != NI_TEST_RETCODE_END_OF_STREAM) {
            ret = filter_frame(&watermark_ctx, p_uphwframe, &out_frame, &watermark_data,
                               &watermark_params, &upload_params);
            if (ret) {
                return ret;
            }
        } else {
                watermark_data.data.frame.end_of_stream = 1;
        }
        if(enc_ctx.session_id == NI_INVALID_SESSION_ID) {
            // Open the encoder session with given parameters
            ret = encoder_open_session(&enc_ctx, dst_codec_format, iXcoderGUID,
                                       &p_enc_api_param, arg_width, arg_height,
                                       &watermark_data.data.frame);
        }
        // YUV Sending
        send_fin_flag = encoder_send_data2(&enc_ctx,
                                           &watermark_data,
                                           &enc_in_frame,
                                           input_video_width,
                                           input_video_height,
                                           &xcoder_state);
        if (send_fin_flag < 0) { //Error
            break;
        }
        p_hwframe = (niFrameSurface1_t *)watermark_data.data.frame.p_data[3];
        ni_hw_frame_ref(g_hwframe_pool, p_hwframe);
        ni_frame_wipe_aux_data(&watermark_data.data.frame);

encode_recv:
        receive_fin_flag = encoder_receive(&enc_ctx,
                                           &out_packet,
                                           &number_of_packets_list,
                                           1, &p_file,
                                           &xcoder_state);
        if (!xcoder_state.enc_eos_received) {
            ni_log(NI_LOG_DEBUG, "enc continues to read!\n");
            end_of_all_streams = 0;
        } else {
            ni_log(NI_LOG_INFO, "enc eos !\n");
            end_of_all_streams = 1;
        }

        if (print_time) {
            time_diff = (uint32_t)(current_time.tv_sec - start_time.tv_sec);
            if (time_diff == 0) {
                time_diff = 1;
            }
            ni_log(NI_LOG_INFO, "[ENC] Packets= %u fps=%f\n",
                   enc_ctx.frame_num, (float)enc_ctx.frame_num / (float)time_diff);
        }
    }

    time_diff = (uint32_t)(current_time.tv_sec - start_time.tv_sec);
    if (time_diff == 0) {
        time_diff = 1;
    }
    ni_log(NI_LOG_INFO, "[DEC] Frames= %u  fps=%f \n",
           number_of_frames, (float)number_of_frames / (float)time_diff);
    ni_log(NI_LOG_INFO, "[ENC] Packets= %u fps=%f\n",
           enc_ctx.frame_num, (float)enc_ctx.frame_num / (float)time_diff);

    if(p_uphwframe)
        ni_hwframe_buffer_recycle2(p_uphwframe);

    ni_device_session_close(&dec_ctx, 1, NI_DEVICE_TYPE_DECODER);
    ni_device_session_close(&upl_ctx, 1, NI_DEVICE_TYPE_UPLOAD);
    ni_device_session_close(&watermark_ctx, 1, NI_DEVICE_TYPE_SCALER);
    ni_device_session_close(&enc_ctx, 1, NI_DEVICE_TYPE_ENCODER);

    ni_device_session_context_clear(&enc_ctx);
    ni_device_session_context_clear(&upl_ctx);
    ni_device_session_context_clear(&dec_ctx);
    ni_device_session_context_clear(&watermark_ctx);

    ni_packet_buffer_free(&(out_packet.data.packet));
    ni_frame_buffer_free(&(in_frame.data.frame));
    ni_frame_buffer_free(&(watermark_data.data.frame));
    ni_frame_buffer_free(&(enc_in_frame.data.frame));

end:    
    for(input_index = 0; input_index < MAX_INPUT_FILES; input_index++) {
        if (file_reader[input_index].file_cache) {
            free(file_reader[input_index].file_cache);
        }
        close(input_file_fd[input_index]);
    }

    if (p_file) {
        fclose(p_file);
    }

    if (yuv_buf) {
        free(yuv_buf);
    }

    ni_log(NI_LOG_INFO, "All done\n");

    return 0;
}
